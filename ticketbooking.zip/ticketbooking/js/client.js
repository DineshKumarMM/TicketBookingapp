var wsUri = "ws://127.0.0.1:7777";
var websocket = new WebSocket(wsUri);
setTimeout(function () {
    if (websocket.readyState != 1) {
        alert("Problem connection , kindly contact system admin .");
        $(".ticketbook").hide();
        $(".errorpage").show();
    }
}, 1000);

function onLoad() {
    websocket.onopen = function (evt) {
        onOpen(evt)
    };
    websocket.onclose = function (evt) {
        if (evt) {
            onClose(evt)
        } else {
            alert("123")
        }
    };
    websocket.onmessage = function (evt) {
        onMessage(evt)
    };
    websocket.onerror = function (evt) {
        if (evt) {
            onError(evt)
        } else {
            alert("123")
        }
    };
}

function onMessage(evt) {
    var message = JSON.parse(evt.data);
    var aaa = document.getElementById(message.id);
    if (message.sameclient) {
        if (message.remove) {
            aaa.classList.remove("selectedseat");
        } else {
            aaa.classList.add("selectedseat");
        }
    } else {
        if (message.remove) {
            aaa.classList.remove("selectedseated");
        } else {
            aaa.classList.add("selectedseated");
        }
    }
    console.log(message);
}

function onOpen(evt) {
    console.log("onOpen")
}

function onClose(evt) {
    console.log("onClose")
}

function onError(evt) {
    alert("Error!");
}

$(document).on("click", ".ticketbook span", function () {
    var docget = document.getElementById($(this).html());
    var getstyle = $(docget).attr('class');
    if (getstyle && getstyle.includes("selectedseat")) {
        var json = {
            remove: true,
            id: $(this).html()
        };
        websocket.send(JSON.stringify(json));
    } else {
        var json = {
            remove: false,
            id: $(this).html()
        }
        websocket.send(JSON.stringify(json));
    }

})
$(document).ready(function () {
    onLoad();
    $(".errorpage").hide();
    var ticketseatarray = [];
    for (i = 1; i <= 30; i++) {
        var ticketresult = '<span id=' + i + '>' + i + '</span>';
        ticketseatarray.push(ticketresult)
    }
    $(".ticketbook").html(ticketseatarray.join(''));
})