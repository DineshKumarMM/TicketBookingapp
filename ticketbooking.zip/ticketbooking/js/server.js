const WebSocket = require('ws');
const _ = require('lodash')

const wss = new WebSocket.Server({
    port: 7777
});

wss.on('connection', function connection(ws) {
    console.log("Connected to...");
    ws.on('message', function incoming(message) {
        let JsonMessage = JSON.parse(message);
        console.log('received: %s', message);
        wss.clients.forEach(function (client) {
            if (_.isEqual(ws, client)) {
                console.log("same client")
                let json = {
                    sameclient: true,
                    id: JsonMessage.id,
                    remove: JsonMessage.remove
                };
                client.send(JSON.stringify(json));
            } else {
                console.log("diff client");
                let json = {
                    sameclient: false,
                    id: JsonMessage.id,
                    remove: JsonMessage.remove
                };
                client.send(JSON.stringify(json));
            }

        });
    });
});